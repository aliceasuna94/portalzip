<?php

namespace App\Traits;

use App\Models\Activation;
use App\Models\Periode;
use App\Models\User;
use Illuminate\Http\Request;

trait QueryTrait {

    /**
     * @param Request $request
     * @return $this|false|string
     */
    

}