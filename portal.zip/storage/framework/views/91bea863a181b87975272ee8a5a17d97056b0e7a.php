<div class="col-md">
    <div class="card card-action mb-4">
      <div class="card-header">
        <div class="card-action-title">
          <span><h5>Status Aktivasi</h5></span>

          <?php if($aktivasi['activation'] == 1): ?>
          <span class="badge bg-success">AKTIF</span>
          <?php else: ?>
          <span class="badge bg-danger">NONAKTIF</span>
          <?php endif; ?>

        </div>
      </div>
      <div class="collapse show" style="">
        <div class="card-body pt-0">
          <p class="card-text">Untuk mengaktifkan penginputan sistem penjamin mutu internal (spmi), status aktivasi harus Aktif. Untuk meng-aktifkan / me-nonaktifkan, silahkan klik tombol dibawah ini.</p>

          <form action="/admin/aktivasi" method="post"> <?php echo csrf_field(); ?>
            <?php if($aktivasi['activation'] == 1): ?>
                <button type="submit" class="btn btn-danger" style="margin-right: 15px"><i class="bx bx-x mt-n1"></i> Non-Aktifkan Penginputan SPMI</button>
            <?php else: ?>
                <button type="submit" class="btn btn-primary" style="margin-right: 15px"><i class="bx bx-check mt-n1"></i> Aktifkan Penginputan SPMI</button>
            <?php endif; ?>
          </form>
          
        </div>
      </div>
    </div>
  </div><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/administrator/periode/_status_aktivasi.blade.php ENDPATH**/ ?>