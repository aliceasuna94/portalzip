<div class="col-md">
    <div class="card card-action mb-4">
      <div class="card-header">
        <div class="card-action-title"><span><h5>Tahun Aktif</h5></span>
          <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($p->status == 1): ?>
              <span class="badge bg-success"><?php echo e($p->tahun); ?></span>
              <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
      </div>
      <div class="collapse show" style="">
        <div class="card-body pt-0">
          <form action="/admin/periode/select" method="POST">
            <?php echo csrf_field(); ?>
            <select class="form-select mb-2" id="exampleFormControlSelect1" aria-label="Default select example" name="id">
              <option selected="">Pilih...</option>
              <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($p->id ?? 0); ?>"><?php echo e($p->tahun ?? 0); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="card-text">Untuk mengubah periode, silahkan pilih tahun dan klik tombol dibawah ini.</p>
            <button type="submit" class="btn btn-primary" style="margin-right: 15px"><i class="bx bx-plus mt-n1"></i> Konfirmasi Periode</button>
        </form>
        </div>
      </div>
    </div>
</div><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/administrator/periode/_tahun_aktif.blade.php ENDPATH**/ ?>