<!-- Dashboard -->
<li class="menu-item <?php echo e(Request::is('home/dashboard*') ? 'active' : ''); ?>">
<a href="/home/dashboard" class="menu-link">
    <i class="menu-icon tf-icons bx bx-home-circle"></i>
    <div data-i18n="Analytics">Dashboard</div>
</a>
</li><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/layout/_dashboard.blade.php ENDPATH**/ ?>