


<?php $__env->startSection('content'); ?>
    
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">SPMI /</span> <?php echo e(ucfirst($url)); ?></h4>

<!--INCLUDE -->
<?php echo $__env->make('trait._error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('trait._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($url == 'evaluasi'): ?>
    <?php echo $__env->make('admin.spmi._tabel_evaluasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.spmi._input_evaluasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.spmi._tabel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.spmi._input', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php echo $__env->make('admin.spmi._tampilkan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/spmi/pengaturan.blade.php ENDPATH**/ ?>