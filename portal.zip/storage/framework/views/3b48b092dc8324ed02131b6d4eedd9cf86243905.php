

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><a style="color: inherit" href="/admin/validasi">Validasi</a></span> / <span><?php echo e(ucwords($prodi->nama)); ?></span></h4>

<!--INCLUDE -->
<?php echo $__env->make('trait._error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('trait._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $pengaturan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card mb-3">
        <h5 class="card-header"><?php echo e(Str::title($p->nama)); ?></h5>
        <div class="table-responsive text-wrap">
        <table class="table table-hover">
            <thead>
            <tr>
                <th>Nama Pengaturan</th>
                <?php if($p->nama != 'evaluasi'): ?> <th>Pilihan</th> <?php endif; ?>
                <?php if($p->nama != 'evaluasi'): ?> <th>Ditetapkan</th> <?php else: ?> <th>Terakhir Dilaksanakan</th> <?php endif; ?> 
                <th>Ditambahkan</th>
                <th>Validasi</th>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('konfirmasi validasi')): ?>
                    <th>Aksi</th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $p->subpengaturan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->tipe != 2): ?>
                    <tr>
                        <td><?php echo e($data->judul); ?></td>
        
                        <?php if($data->isian_by_prodi != null): ?>
                            <?php if($p->nama != 'evaluasi'): ?>
                                <td>
                                    <?php if($data->isian_by_prodi['jawaban'] == 1): ?>
                                    <span class="badge bg-label-success me-1">Ada</span>
                                    <?php else: ?>
                                    <span class="badge bg-label-warning me-1">Tidak Ada</span>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                            <td><?php echo e($data->isian_by_prodi['tanggal']); ?></td>
                            <td><?php echo e(substr($data->isian_by_prodi['created_at'], 0, 10)); ?></td>
                            <td>
                                <?php if($data->isian_by_prodi['verifikasi'] == 0): ?>
                                    <span class="badge bg-label-primary me-1">Not Validated</span>
                                <?php elseif($data->isian_by_prodi['verifikasi'] == 1): ?>
                                    <span class="badge bg-label-success me-1">Accepted</span>
                                <?php else: ?>
                                    <span class="badge bg-label-danger me-1">Rejected</span>
                                <?php endif; ?>
                            </td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('konfirmasi validasi')): ?>
                                <td style="width: 100px">
                                    <button type="button" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true" title="" data-bs-original-title="<span>Tampilkan & Validasi</span>" class="btn btn-sm btn-icon btn-primary" data-pengaturan="<?php echo e($data); ?>" onclick="tampilkanPengaturan(this)">
                                    <span class="tf-icons bx bxs-show"></span></button>
                                </td>
                            <?php endif; ?>
                        <?php else: ?>
                            <td colspan="7" style="text-align: center;"><span style="font-style: italic;">Belum mengisi</span></td>
                        <?php endif; ?>
                        
                    </tr>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
            </tbody>
        </table>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="card mb-3 mt-2">
    <div class="table-responsive text-wrap">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>List mekanisme evaluasi lainnya yang dilakukan</th>
            <th>Terakhir Dilaksanakan</th>
            <th>Validasi</th>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('konfirmasi validasi')): ?> <th>Aksi</th> <?php endif; ?>
            
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">
          <?php if($tambahan->count()): ?>
              <?php $__currentLoopData = $tambahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data->judul); ?></td>
  
                    <td><?php echo e(substr($data->created_at, 0, 10)); ?></td>
                    <td>
                        <?php if($data->verifikasi == 0): ?>
                            <span class="badge bg-label-primary me-1">Not Validated</span>
                        <?php elseif($data->verifikasi == 1): ?>
                            <span class="badge bg-label-success me-1">Accepted</span>
                        <?php else: ?>
                            <span class="badge bg-label-danger me-1">Rejected</span>
                        <?php endif; ?>
                    </td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('konfirmasi validasi')): ?>
                        <td style="width: 100px">
                            <button type="button" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true" title="" data-bs-original-title="<span>Tampilkan & Validasi</span>" class="btn btn-sm btn-icon btn-primary" data-pengaturan="<?php echo e($data); ?>" onclick="tampilkanPengaturanEvaluasitambahan(this)">
                            <span class="tf-icons bx bxs-show"></span></button>                       
                        </td>
                    <?php endif; ?>
                    
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
              <tr>
                <td colspan="4" class="text-center">Tidak ada evaluasi tambahan.</td>
              </tr>
          <?php endif; ?>

        </tbody>
      </table>
    </div>
  </div>

  <?php echo $__env->make('admin.administrator.validasi._tampilkan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/administrator/validasi/validasi.blade.php ENDPATH**/ ?>