

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Admin /</span> Program Studi</h4>

<!--INCLUDE -->
<?php echo $__env->make('trait._error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('trait._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.administrator.prodi._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.administrator.prodi._tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.administrator.prodi._link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/administrator/prodi/prodi.blade.php ENDPATH**/ ?>