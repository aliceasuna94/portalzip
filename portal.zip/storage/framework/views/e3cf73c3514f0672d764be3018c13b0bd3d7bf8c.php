<div class="col-md-6">
    <div class="card">
          <h5 class="card-header">Daftar Periode</h5>
      
        <div class="table-responsive text-nowrap">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>Tahun Periode</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody class="table-border-bottom-0">
              
              <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($p->tahun ?? ''); ?></td>
                <td>
                  <div class="d-inline-block text-nowrap">
                    <form action="/admin/periode" method="post">
                        <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                        <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                        <button type="submit" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true" title="" data-bs-original-title="<span>Hapus</span>" class="btn btn-sm btn-icon delete-record" onclick="return confirm('Yakin menghapus periode ini ?')"><i class="bx bx-trash"></i></button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
            </tbody>
          </table>
        </div>
      </div>
</div><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/administrator/periode/_tabel.blade.php ENDPATH**/ ?>