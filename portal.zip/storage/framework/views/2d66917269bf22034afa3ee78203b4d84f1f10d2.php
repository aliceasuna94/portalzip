


<?php $__env->startSection('content'); ?>
    
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Hubungi Kami</h4>

<div class="row">
  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Hubungi Kami</h5>
      <ul class="list-group">
        <li class="list-item d-flex align-items-center">
          <i class="bx bx-envelope me-2"></i>
          xcvgfdxcvgfdx@gmail.com
        </li>
        
      </ul>
    </div>
    
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/about/hubungi.blade.php ENDPATH**/ ?>