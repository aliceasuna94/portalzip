<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?><?php /**PATH E:\BELAJAR LARAVEL\Backup Portaldata 2022 Merge\portaldata\resources\views/trait/_success.blade.php ENDPATH**/ ?>