
<form action="/admin/prodi/link" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" id="accid">
    <div class="mt-3">
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#basicModal4" id="btnSambungAkun" hidden>Launch modal</button>
  
      <!-- Modal -->
      <div class="modal fade" id="basicModal4" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Sambungkan Akun</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
  
              <div class="row">
                <div class="col mb-3">
                  <label for="username" class="form-label">nama prodi</label>
                  <input class="form-control" type="username" id="link_username" disabled>
                </div>
              </div>
              <div class="row">
                <div class="col mb-3">
                  <label for="akun" class="form-label">Akun</label>
                  <select class="form-select" name="account" id="account_link">
                      <option value="">Pilih...</option>
                      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($us->prodi == null): ?>
                              <option value="<?php echo e($us->id); ?>"><?php echo e($us->name); ?></option>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
  
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
  
  <script>
    function linkAccount(e) {
      const data = JSON.parse(e.dataset.user);
      console.log(data);
      document.getElementById('accid').value = data.id;
      document.getElementById('link_username').value = data.nama;
      document.getElementById('btnSambungAkun').click();
    }
  </script><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/administrator/prodi/_link.blade.php ENDPATH**/ ?>