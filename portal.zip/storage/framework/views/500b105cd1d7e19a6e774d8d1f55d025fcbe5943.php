

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Prodi /</span> Pangkalan Data </h4>

<!--INCLUDE -->
<?php echo $__env->make('trait._error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('trait._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.profil._data_mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.profil._data_dosen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BELAJAR LARAVEL\Backup Portaldata 2022 Merge\portaldata\resources\views/admin/profil/data.blade.php ENDPATH**/ ?>