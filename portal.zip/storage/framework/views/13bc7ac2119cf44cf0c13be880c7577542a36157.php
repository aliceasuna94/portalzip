

<?php $__env->startSection('content'); ?>

<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Prodi /</span> Profil </h4>

<!--INCLUDE -->
<?php echo $__env->make('trait._error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('trait._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row fv-plugins-icon-container">
    <div class="col-md-12">
      <div class="card mb-4">
        <h5 class="card-header">Rincian Profil</h5>
  
        <form action="/prodi/profil/create" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <!-- Account -->
        <hr class="my-0">
        <div class="card-body">
          <form id="formAccountSettings" method="POST" onsubmit="return false">
            <div class="row">
  
              <div class="mb-3 col-md-6">
                <label for="namaprodi" class="form-label">Nama Prodi</label>
                <input class="form-control" type="text" id="namaprodi" value="<?php echo e(ucwords(auth()->user()->prodi->nama)); ?>" disabled>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="kodeprodi" class="form-label">Kode Prodi</label>
                <input class="form-control" type="text" id="kodeprodi" value="<?php echo e(auth()->user()->prodi->kode); ?>" disabled>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="fakultas" class="form-label">Fakultas</label>
                    <input class="form-control" type="text" id="fakultas" value="<?php echo e(auth()->user()->prodi->faculty->name); ?>" disabled>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="universitas" class="form-label">Perguruan Tinggi</label>
                <input class="form-control" type="text" id="universitas" value="Universitas Tadulako" disabled>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="akreditasi" class="form-label">Akreditasi</label>
                <select class="form-select" name="akreditasi" id="akreditasi">
                    <option value="0">Tidak Terakreditasi</option>
                    <option value="1">Akreditasi A</option>
                    <option value="2">Akreditasi B</option>
                    <option value="3">Akreditasi C</option>
                    <option value="4">Unggul</option>
                    <option value="5">Baik</option>
                    <option value="6">Baik Sekali</option>
                </select>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="jenjang" class="form-label">Jenjang</label>
                <input class="form-control" type="text" id="jenjang" value="<?php echo e(auth()->user()->prodi->jenjang); ?>" disabled>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="nilai" class="form-label">Nilai Akreditasi</label>
                <input class="form-control" type="text" id="nilai" name="nilai" value="<?php echo e($profil->nilai ?? ''); ?>">
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="berlaku" class="form-label">Akreditasi Berlaku Sampai</label>
                <input class="form-control" type="date" id="berlaku" name="berlaku" value="<?php echo e($profil->berlaku ?? ''); ?>">
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="skakreditasi" class="form-label">SK Akreditasi (PDF)</label>
                <div class="input-group">
                  <input type="file" accept="application/pdf" class="form-control" id="skakreditasi" name="sk_akreditasi"  aria-describedby="inputGroupFileAddon04" aria-label="Upload">
  
                    <?php if($profil->sk_akreditasi ?? ''): ?>
                        <a href="<?php echo e(Storage::url($profil->sk_akreditasi)); ?>" target="_blank"><button class="btn btn-primary" type="button"><span class="tf-icons bx bx-show"></button></a>   
                    <?php endif; ?>
  
                </div>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="lembagaakreditasi" class="form-label">Lembaga Pengakreditasi</label>
                <input class="form-control" type="text" id="lembagaakreditasi" name="lembaga" value="<?php echo e($profil->lembaga ?? ''); ?>">
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="akreditasiint" class="form-label">Akreditasi Internasional</label>
                <select class="form-select" name="akreditasi_internasional" id="akreditasiint">
                    <?php if(($profil->akreditasi_internasional ?? 0) == 0): ?>
                      <option value="0" selected>Tidak Terakreditasi</option>
                      <option value="1">Terakreditasi</option>
                    <?php else: ?>
                      <option value="0">Tidak Terakreditasi</option>
                      <option value="1" selected>Terakreditasi</option> 
                    <?php endif; ?>

                </select>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="skakreditasiinter" class="form-label">SK Akreditasi Internasional (PDF)</label>
                <div class="input-group">
                  <input type="file" accept="application/pdf" class="form-control" id="skakreditasiinter" name="sk_akreditasi_internasional"  aria-describedby="inputGroupFileAddon04" aria-label="Upload">
  
                  <?php if($profil->sk_akreditasi_internasional ?? ''): ?>
                        <a href="<?php echo e(Storage::url($profil->sk_akreditasi_internasional)); ?>" target="_blank"><button class="btn btn-primary" type="button"><span class="tf-icons bx bx-show"></button></a>   
                  <?php endif; ?>
  
                </div>
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="lembagaakreditasiinter" class="form-label">Lembaga Pengakreditasi Internasional</label>
                <input class="form-control" type="text" id="lembagaakreditasiinter" name="lembaga_internasional" value="<?php echo e($profil->lembaga_internasional ?? ''); ?>">
              </div>
  
              <div class="mb-3 col-md-6">
                <label for="berlakuinter" class="form-label">Akreditasi Internasional Berlaku Sampai</label>
                <input class="form-control" type="date" id="berlakuinter" name="berlaku_internasional" value="<?php echo e($profil->berlaku_internasional ?? ''); ?>">
              </div>
                  
            </div>
            <div class="mt-2">
              <button type="submit" class="btn btn-primary me-2">Save changes</button>
            </div>
          <div></div><input type="hidden"></form>
        </div>
        <!-- /Account -->
      </form>
  
      </div>
  
    </div>
  </div>

  <script>

    //Set Akreditasi
    var akreditasi = '<?php if($profil): ?> <?php echo e($profil->akreditasi); ?> <?php else: ?> 0 <?php endif; ?>';
    document.getElementById("akreditasi").value = akreditasi.trim();
    
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/profil/profil.blade.php ENDPATH**/ ?>