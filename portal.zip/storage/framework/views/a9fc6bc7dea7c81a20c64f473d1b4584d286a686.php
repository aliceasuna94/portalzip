<?php if(auth()->check() && auth()->user()->hasRole('rektor')): ?>
    <!-- Components -->
    <li class="menu-header small text-uppercase">
        <span class="menu-header-text">SPMI</span>
    </li>
    <!-- Cards -->
    <li class="menu-item <?php echo e(Request::is('universitas/programstudi') ? 'active' : ''); ?>">
        <a href="/universitas/programstudi" class="menu-link">
            <i class="menu-icon tf-icons bx bx-buildings"></i>
            <div data-i18n="Basic">Program Studi</div>
        </a>
    </li>
    <!-- Cards -->
    <li class="menu-item <?php echo e(Request::is('universitas/akreditasi') ? 'active' : ''); ?>">
        <a href="/universitas/akreditasi" class="menu-link">
            <i class="menu-icon tf-icons bx bx-award"></i>
            <div data-i18n="Basic">Akreditasi</div>
        </a>
    </li>
<?php endif; ?><?php /**PATH E:\BELAJAR LARAVEL\Backup Portaldata 2022 Merge\portaldata\resources\views/admin/layout/_rektor.blade.php ENDPATH**/ ?>