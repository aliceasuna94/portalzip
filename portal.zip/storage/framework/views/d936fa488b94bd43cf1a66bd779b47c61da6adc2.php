
<div class="card">
    <div class="row">
      <div class="col-sm"><h5 class="card-header">Daftar Prodi</h5></div>
      <div class="col-sm mt-3" style="text-align: right">
        <button type="button" class="btn btn-primary" style="margin-right: 15px" onclick="tambahProdi()"><i class='bx bx-plus mt-n1'></i> Tambah Prodi</button></div>
    </div>
  
    <div class="table-responsive text-wrap">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Kode Prodi</th>
            <th>Nama Prodi</th>
            <th>Fakultas</th>
            <th>Jenjang</th>
            <th>User Linked</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">
          
          <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($p->kode ?? ''); ?></td>
            <td><?php echo e(ucwords($p->nama) ?? ''); ?></td>
            <td><?php echo e($p->faculty['singkatan'] ?? ''); ?></td>
            <td><?php echo e($p->jenjang ?? ''); ?></td>
            
            <td><span class="badge bg-label-primary"><?php echo e($p->users['username']); ?></span></td>
            <td>
              <div class="d-inline-block text-nowrap">
  
                <button data-user="<?php echo e($p); ?>" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true" title="" data-bs-original-title="<span>Sambungkan Akun</span>" class="btn btn-sm btn-icon delete-record" onclick="linkAccount(this)"><i class="bx bx-link-alt"></i></button>
                
                <form action="/admin/prodi" method="post" style="display: contents">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <input type="hidden" name="id" value="<?php echo e($p->id); ?>" required>
                  <button type="submit" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true" title="" data-bs-original-title="<span>Hapus</span>" class="btn btn-sm btn-icon delete-record" onclick="return confirm('Yakin menghapus prodi ini?')"><i class="bx bx-trash"></i></button>
                </form>
  
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
        </tbody>
      </table>
    </div>
  </div><?php /**PATH E:\BELAJAR LARAVEL\portaldata\resources\views/admin/administrator/prodi/_show.blade.php ENDPATH**/ ?>