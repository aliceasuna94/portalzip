# portaldata
Portal data universitas tadulako
