<!-- Dashboard -->
<li class="menu-item {{ Request::is('home/dashboard*') ? 'active' : '' }}">
<a href="/home/dashboard" class="menu-link">
    <i class="menu-icon tf-icons bx bx-home-circle"></i>
    <div data-i18n="Analytics">Dashboard</div>
</a>
</li>